﻿namespace SyncTrayzor.Services.Config
{
    public enum IconAnimationMode
    {
        Disabled,
        Syncing,
        DataTransferring,
    }
}
