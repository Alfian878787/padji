Contributing to SyncTrayzor
===========================

When opening an issue, you **must** include the SyncTrayzor version and Syncthing version.
For crashes, please provide the full stack trace that SyncTrayzor gave you in its 'Oops! Something went badly wrong' window.

If you're multi-lingual? SyncTrayzor needs you! Please read [Localization](https://github.com/canton7/SyncTrayzor/wiki/Localization).

Want to make a code contribution? Fantastic, and thank you! Please read [Contributing](https://github.com/canton7/SyncTrayzor/wiki/Contributing) first.