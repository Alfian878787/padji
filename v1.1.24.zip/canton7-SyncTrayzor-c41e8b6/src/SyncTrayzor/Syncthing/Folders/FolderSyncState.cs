﻿namespace SyncTrayzor.Syncthing.Folders
{
    public enum FolderSyncState
    {
        Syncing,
        Scanning,
        Idle,
        Error,
    }
}
